import os
import secrets
import warnings
import itertools
import numpy as np
import pandas as pd
from datetime import date, datetime
from sqlalchemy import desc, asc, func
from flask import render_template, url_for, flash, redirect, request, abort, jsonify, send_file
from flask_login import login_user, current_user, logout_user, login_required
from app import app, db, bcrypt
from app.forms import RegistrationForm, LoginForm, UpdateAccountForm, PostForm, TestFrom
from app.models import User, Post, Orders
from app.decomposed import Decomposed
from app.prediction import calc, predict, Forecast, error

import io
import base64
import matplotlib.pyplot as plt
import matplotlib.style as st
import matplotlib
matplotlib.use('Agg')

@app.route("/")
@app.route("/trends", methods=['GET', 'POST'])
def trends():
    if current_user.is_authenticated:
        cat = Orders.query.with_entities(Orders.category).group_by(Orders.category).all()
        states = Orders.query.with_entities(Orders.state).filter_by(country="United States").group_by(Orders.state).all()
        return render_template('tr.html', cat=cat, states=states)
    if current_user.is_anonymous:
        return render_template('unauthenticated.html')

@app.route("/_trends", methods=['GET', 'POST'])
def _trends():
    category = request.form['category']
    state = request.form['state']
    od_start = request.form['start']
    od_end = request.form['end']
    if od_start and od_end:
        start = datetime.strptime(od_start, '%d-%m-%Y').strftime('%Y-%m-%d')
        end = datetime.strptime(od_end, '%d-%m-%Y').strftime('%Y-%m-%d')
    granularity = request.form['granularity']
    n_step = int(request.form['n_step'])

    orders = Orders.query.filter(Orders.order_date >= start).filter(Orders.order_date <= end).filter_by(country="United States").filter_by(category=category).filter_by(state=state).order_by(asc(Orders.order_date))

    data_list = []
    for v in orders:
        odx = datetime.strptime(str(v.order_date), '%Y-%m-%d').strftime('%Y-%m-%d')
        sdx = datetime.strptime(str(v.ship_date), '%Y-%m-%d').strftime('%Y-%m-%d')
        id = v.id
        order_id = str(v.order_id)
        order_date = odx
        ship_date = sdx
        ship_mode = str(v.ship_mode)
        customer_id = str(v.customer_id)
        customer_name = str(v.customer_name)
        segment = str(v.segment)
        city = str(v.city)
        state = str(v.state)
        country = str(v.country)
        postal_code = str(v.postal_code)
        market = str(v.market)
        region = str(v.region)
        product_id = str(v.product_id)
        category = str(v.category)
        sub_category = str(v.sub_category)
        product_name = str(v.product_name)
        sales = v.sales
        quantity = v.quantity
        discount = v.discount
        profit = v.profit
        shipping_cost = v.shipping_cost
        order_priority = str(v.order_priority)

        op = (id, order_id, order_date, ship_date, ship_mode, customer_id, customer_name, segment, city, state, country, postal_code, market, region, product_id, category, sub_category, product_name, sales, quantity, discount, profit, shipping_cost, order_priority)

        data_list.append(op)

    df = pd.DataFrame(data_list)
    df.columns = ["id", "order_id", "order_date", "ship_date", "ship_mode", "customer_id", "customer_name", "segment", "city", "state", "country", "postal_code", "market", "region", "product_id", "category", "sub_category", "product_name", "sales", "quantity", "discount", "profit", "shipping_cost", "order_priority"]

    df['order_date'] = pd.to_datetime(df.order_date)

    dt_info = str(df.shape[0]) + ' data transaction'

    warnings.filterwarnings("ignore")

    cols = ['id', 'order_id', 'ship_date', 'ship_mode', 'customer_id', 'customer_name', 'segment', 'country', 'city', 'state', 'postal_code', 'discount', 'region', 'product_id', 'category', 'sub_category', 'product_name', 'quantity', 'profit']

    df.drop(cols, axis=1, inplace=True)
    df = df.sort_values('order_date')
    df.isnull().sum()
    df = df.groupby('order_date')['sales'].sum().reset_index()
    df= df.set_index(df['order_date'])

    y = df['sales'].resample(granularity).mean()
    y = y.fillna(y.bfill())

    # Data to display
    category_info = category
    country_info = 'United States'
    state_info = state
    od_info = od_start + ' to ' + od_end

    text1 = 'Trends & Seasonality'
    text2 = ''
    text3 = 'Seasonality'
    text4 = 'Prediction'

    dl = len(y)

    yl = ''
    fr = 0
    day = 0 
    week = 0
    month = 0
    year = 0

    if granularity == 'D':
        yl = 'Daily'
        if dl == 365:
            fr = 365
        elif dl > 365:
            fr = 365
        elif dl < 365:
            fr = dl
    
    if granularity == 'W':
        yl = 'Weekly'
        if dl == 52:
            fr = 52
        elif dl > 52:
            fr = 52
        elif dl < 52:
            fr = dl
    
    if granularity == 'M':
        yl = 'Monthly'
        if dl == 12:
            fr = 12
        elif dl > 12:
            fr = 12
        elif dl < 12:
            fr = dl
    if granularity == 'A':
        yl = 'Yearly'
        if dl == 1:
            fr = 1
        elif dl > 1:
            fr = 1
        elif dl < 1:
            fr = dl

    pr_step_info = str(n_step) + ' ' + str(granularity)

    summary, result, result_table = calc(y, fr, n_step)
    prediksi = predict(y, result)
    p, d, q = result_table.parameters[0]
    P, D, Q, s = result_table.seasonal_param[0]

    pdq = str((p, d, q))
    PDQs = str((P, D, Q)) + str(s)

    pdqs_info = 'SARIMA' + pdq + 'x' + PDQs

    if prediksi:
        # prediksi = predict(y, result)
        forecast = Forecast(y, result, n_step, yl)
        mse, rmse = error(y, prediksi)
        mse = str(mse)
        rmse = str(rmse)
        img = io.BytesIO()
        plt.savefig(img, format = 'png')
        ipred = base64.b64encode(img.getvalue()).decode()

    igraph = Decomposed.dviz(y, yl)
    itrend = Decomposed.trend(y, dl, yl)
    iseason = Decomposed.season(y, fr, yl)

    period_info = yl
    period_data_info = yl + ' Sales Averages' 
    ts_summary_info = ''

    if category:
        return jsonify({
            'mse': mse,
            'rmse': rmse,
            'pdq': pdqs_info,
            'category_info': category_info,
            'country_info': country_info,
            'state_info': state_info,
            'od_info': od_info,
            'dt_info': dt_info,
            'text1': text1,
            'text2': text2,
            'plot1': igraph,
            'text3': text3,
            'plot2': itrend,
            'text4': text4,
            'plot3': iseason,
            'period_info': period_info,
            'period_data_info': period_data_info,
            'ts_summary_info': ts_summary_info,
            'plot4': ipred,
            'pr_step_info': pr_step_info,
            'pr_rmse_info': rmse,
            'pr_mse_info': mse
        })
    else:
        return jsonify({'error': 'Missing data!'})

@app.route("/home")
def home():
    posts = Post.query.all()
    return render_template('home.html', posts=posts)

@app.route("/about-us")
def about():
    return render_template('about.html', title='About')

@app.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect('/')
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)

@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect('home')
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect('/')
        else:    
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html', title='Login', form=form)

@app.route("/logout")
def logout():
    logout_user()
    return redirect('/')

def save_picture(form_picture):
    random_hex = secrets.token_hex(8)
    f_name, f_ext = os.path.splitext(form_picture.filename)
    picture_fn = random_hex + f_ext
    picture_path = os.path.join(app.root_path, 'static/profile_pics', picture_fn)

    output_size = (125, 125)
    i = Image.open(form_picture)
    i.thumbnail(output_size)
    i.save(picture_path)
    return picture_fn

@app.route("/account-info", methods=['GET', 'POST'])
@login_required
def account():
    form = UpdateAccountForm()
    if form.validate_on_submit():
        if form.picture.data:
            picture_file = save_picture(form.picture.data)
            current_user.image_file = picture_file
        current_user.username = form.username.data
        current_user.email = form.email.data
        db.session.commit()
        flash('Your account has been updated.', 'success')
        return redirect(url_for('account'))
    elif request.method == 'GET':
        form.username.data = current_user.username
        form.email.data = current_user.email
    image_file = url_for('static', filename='profile_pics/' + current_user.image_file)
    return render_template('account.html', title='Account', image_file=image_file, form=form)

@app.route("/post/new", methods=['GET', 'POST'])
@login_required
def new_post():
    form = PostForm()
    if form.validate_on_submit():
        post = Post(title=form.title.data, content=form.content.data, author=current_user)
        db.session.add(post)
        db.session.commit()
        flash('Your post has been created.', 'success')
        return redirect(url_for('home'))
    return render_template('create_post.html', title='New Post', form=form, legend='New Post')

@app.route("/post/<int:post_id>")
def post(post_id):
    post = Post.query.get_or_404(post_id)
    return render_template('post.html', title=post.title, post=post)

@app.route("/post/<int:post_id>/update", methods=['GET', 'POST'])
@login_required
def update_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.author != current_user:
        abort(403)
    form = PostForm()
    if form.validate_on_submit():
        post.title = form.title.data
        post.content = form.content.data
        db.session.commit()
        flash('Your post has been updated.', 'success')
        return redirect(url_for('post', post_id=post.id))
    elif request.method == 'GET':
        form.title.data = post.title
        form.content.data = post.content
    return render_template('create_post.html', title="Update Post", form=form, legend='Update Post')

@app.route("/post/<int:post_id>/delete", methods=['POST'])
@login_required
def delete_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.author != current_user:
        abort(403)
    db.session.delete(post)
    db.session.commit()
    flash('Your post has been deleted.', 'success')
    return redirect(url_for('home'))

@app.route('/guide-predicting-process/')
def guide_predicting_process():
    try:
        return send_file('pdf/guide_predicting_process.pdf', attachment_filename='guide_predicting_process.pdf')
    except Exception as e:
        return str(e)

@app.route('/guide-sales-predicting/')
def guide_sales_predicting():
    try:
        return send_file('pdf/guide_sales_predicting.pdf', attachment_filename='guide_sales_predicting.pdf')
    except Exception as e:
        return str(e)

@app.route("/download-guide")
def guide():
    return render_template('guide.html')