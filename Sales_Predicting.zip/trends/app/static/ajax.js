$(document).ready(function() {
    $("#trend-submit").on("click", function(event) {

        $("#contentx").hide();
        $.ajax({
            data: {
                category: $("#item-category").val(),
                state: $("#state").val(),
                start: $("#order-date-start").val(),
                end: $("#order-date-end").val(),
                granularity: $("#granularity").val(),
                n_step: $('#step-range').val()
            },
            type: 'POST',
            url: '/_trends',
            beforeSend: function () {
                $('#loader-x').show();
                $("#graphx").hide();
            },
            complete: function () {
                $("#loader-x").hide();
            },
            success: function(data) {
                if (data) {

                    $("#contentx").slideDown(1000);

                    var vplot1 = 'data:image/png;base64,' + data.plot1;
                    var vplot2 = 'data:image/png;base64,' + data.plot2;
                    var vplot3 = 'data:image/png;base64,' + data.plot3;
                    var vplot4 = 'data:image/png;base64,' + data.plot4;
   
                    $('#plot1').attr('src', vplot1);
                    $('#plot2').attr('src', vplot2);
                    $('#plot3').attr('src', vplot3);
                    $('#plot4').attr('src', vplot4);
                    
                    $("#category-info").html("<span>&#9679; &nbsp; Category &#8764; </span>" + data.category_info);
                    $("#country-info").html("<span>&#9679; &nbsp; Country &#8764;  </span>" + data.country_info);
                    $("#state-info").html("<span>&#9679; &nbsp; State &#8764;  </span>" + data.state_info);
                    $("#od-info").html("<span>&#9679; &nbsp; Order date &#8764;  </span>" + data.od_info);
                    $("#dt-info").html("<span>&#9679; &nbsp; Dataset &#8764;  </span>" + data.dt_info);

                    $("#text1").text(data.text1);
                    $("#text2").text(data.text2);
                    $("#text3").text(data.text3);
                    $("#text4").text(data.text4);

                    $("#period-info").html("<span>&#9679; &nbsp; Period &#8764; </span>" + data.period_info);
                    $("#period-data-info").html("<span>&#9679; &nbsp; Period data &#8764; </span>" + data.period_data_info + " (USD)");
                    $("#ts-summary-info").html("<span>&#9679; &nbsp; Summary &#8764; </span>" + data.ts_summary_info);

                    $("#pr-step-info").html("<span>&#9679; &nbsp; Predicting (n-steps) &#8764; </span>" + data.pr_step_info);
                    $("#pr-pdq-info").html("<span>&#9679; &nbsp; Model &#8764; </span><code><i>" + data.pdq) + "</i></code>";
                    $("#pr-rmse-info").html("<span>&#9679; &nbsp; RMSE &#8764; </span>" + data.pr_rmse_info);
                    $("#pr-mse-info").html("<span>&#9679; &nbsp; MSE &#8764; </span>" + data.pr_mse_info);

                } else {
                    $("#contentx").hide();
                    $("#graphx").show();
                }
            },
            error: function() {
                $("#graphx").show();
            }
        })
        event.preventDefault();
    })
})
