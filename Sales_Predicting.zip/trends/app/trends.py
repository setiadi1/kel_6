import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')
import statsmodels.api as sm
from pylab import rcParams
import io
import base64

rcParams['figure.figsize'] = 10, 7

class Get(object):

    def trend(s):
        f, ax = plt.subplots(1)
        plt.xlabel('Order Date')
        plt.ylabel('Average Daily Sales')
        plt.grid(True)
        decomposition = sm.tsa.seasonal_decompose(s, model='multiplicative', freq=0.5)
        decomposition.trend.plot()
        img = io.BytesIO()
        plt.savefig(img, format = 'png')
        plot = base64.b64encode(img.getvalue()).decode()
        return plot
    
    def seasonal(s):
        f, ax = plt.subplots(1)
        plt.xlabel('Order Date')
        plt.ylabel('Average Daily Sales')
        plt.grid(True)
        decomposition = sm.tsa.seasonal_decompose(s, model='multiplicative', freq=0.5)
        decomposition.seasonal.plot()
        img = io.BytesIO()
        plt.savefig(img, format = 'png')
        plot = base64.b64encode(img.getvalue()).decode()
        return plot
    
    def decompose(s):
        f, ax = plt.subplots(1)
        plt.xlabel('Order Date')
        plt.ylabel('Average Daily Sales')
        plt.grid(True)
        decomposition = sm.tsa.seasonal_decompose(s, model='multiplicative', freq=0.5)
        decomposition.plot()
        img = io.BytesIO()
        plt.savefig(img, format = 'png')
        plot = base64.b64encode(img.getvalue()).decode()
        return plot